# Open-PBS-Installation-Centos7
OPEN PBS Installation on Centos7/8 Script
- 📫 for more information and contact
- 🖥️ My Website  :- https://chandrabhushan.in
-  🤖 LinkedIn   :- https://www.linkedin.com/in/sweetcbk
-  🤖 Twitter    :- https://twitter.com/sweetcbk
