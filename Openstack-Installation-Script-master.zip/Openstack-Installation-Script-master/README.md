# openstack-installation-script
 Open Stack Installation Process on Centos7/8
Run Command on Centos7/8 Machine
- 📫 for more information and contact
- 🖥️ My Website  :- https://chandrabhushan.in
-  🤖 LinkedIn   :- https://www.linkedin.com/in/sweetcbk
-  🤖 Twitter    :- https://twitter.com/sweetcbk
