# slurm-Installation-script
SLURM Installation Script CentOS7/8
SLURM Installation Script CentOS7/8 with Chrony and NFS
- 📫 for more information and contact
- 🖥️ My Website  :- https://chandrabhushan.in
-  🤖 LinkedIn   :- https://www.linkedin.com/in/sweetcbk
-  🤖 Twitter    :- https://twitter.com/sweetcbk
